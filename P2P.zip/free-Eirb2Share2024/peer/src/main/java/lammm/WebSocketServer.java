package lammm;

/*
 * import javax.websocket.*;
 * import javax.websocket.server.ServerEndpoint;
 * import java.io.IOException;
 * 
 * @ServerEndpoint("/websocket")
 * public class WebSocketServer {
 * 
 * @OnOpen
 * public void onOpen(Session session) {
 * System.out.println("Connexion ouverte : " + session.getId());
 * }
 * 
 * @OnMessage
 * public void onMessage(String message, Session session) {
 * System.out.println("Message reçu : " + message);
 * try {
 * session.getBasicRemote().sendText("Echo : " + message);
 * } catch (IOException e) {
 * e.printStackTrace();
 * }
 * }
 * 
 * @OnClose
 * public void onClose(Session session) {
 * System.out.println("Connexion fermée : " + session.getId());
 * }
 * 
 * @OnError
 * public void onError(Throwable error) {
 * error.printStackTrace();
 * }
 * }
 */
